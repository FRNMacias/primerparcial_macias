var searchData=
[
  ['resize_0',['resize',['../network_8cpp.html#aeb3307904c240055b9787970bba42f77',1,'resize(struct red *v, int vec_size):&#160;network.cpp'],['../network_8h.html#aeb3307904c240055b9787970bba42f77',1,'resize(struct red *v, int vec_size):&#160;network.cpp']]]
];
