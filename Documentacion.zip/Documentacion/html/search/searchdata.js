var indexSectionsWithContent =
{
  0: "bcgilmnrstu",
  1: "r",
  2: "mn",
  3: "bcglmrs",
  4: "iltu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

