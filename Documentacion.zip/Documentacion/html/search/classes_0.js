var searchData=
[
  ['red_0',['red',['../structred.html',1,'']]]
];
