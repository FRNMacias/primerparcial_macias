var searchData=
[
  ['type_0',['type',['../structred.html#a0e6df5d66313d65e463dcfff0e288c44',1,'red']]]
];
