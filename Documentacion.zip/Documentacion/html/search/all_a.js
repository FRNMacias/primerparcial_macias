var searchData=
[
  ['upper_0',['upper',['../structred.html#a2c839516ce59d6ece3891894f966f03a',1,'red']]]
];
