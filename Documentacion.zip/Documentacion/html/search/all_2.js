var searchData=
[
  ['getregister_0',['getRegister',['../network_8cpp.html#ae67459dd06c72f419a3cf0663042be46',1,'getRegister(uint32_t ID_user, struct red *vec, int cant):&#160;network.cpp'],['../network_8h.html#ae67459dd06c72f419a3cf0663042be46',1,'getRegister(uint32_t ID_user, struct red *vec, int cant):&#160;network.cpp']]]
];
