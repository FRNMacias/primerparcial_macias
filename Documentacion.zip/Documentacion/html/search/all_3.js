var searchData=
[
  ['id_0',['ID',['../structred.html#a37b242691f1044dbb5895f6e41663903',1,'red']]],
  ['inf_1',['inf',['../structred.html#a56212a0736a8a8b2419cb10b0fbe2c98',1,'red']]]
];
