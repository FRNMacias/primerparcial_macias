var searchData=
[
  ['lower_0',['lower',['../structred.html#a8804b42929704c04238b50d4cb7707c5',1,'red']]]
];
